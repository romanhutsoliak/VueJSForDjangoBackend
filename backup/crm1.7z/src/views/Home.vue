<template>
  <div class="home">
    <ul>
      <li><a href="/login">login</a></li>
      <li><a href="/categories">categories</a></li>
    </ul>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  }
}
</script>
